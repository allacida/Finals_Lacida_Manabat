# FOLIO — Digital Library

A digital library web app powered by the [Open Library API](https://openlibrary.org/developers/api). No API key required.

## Project Structure

```
folio/
├── index.html   ← Main HTML structure
├── styles.css   ← All CSS styles (light mode, dark mode, glass UI, responsive)
├── script.js    ← All JavaScript (auth, search, reading list, notes, modals)
└── README.md
```

## Features

- 🔍 **Search** books by title, author, ISBN, or all fields
- 📚 **Browse** by subject (Sci-Fi, Fantasy, History, etc.)
- 📖 **Reading List** — save books and export as `.txt`
- 📝 **Book Notes** — jot highlights and thoughts per book
- 🌙 **Dark Mode** toggle (saved in localStorage)
- 🎲 **Random Book** picker
- ⌨️ **Keyboard Shortcuts** (`/` search, `B` browse, `R` reading list, `D` dark mode, etc.)
- 🔐 **Local Auth** — register/login stored in browser localStorage (no server needed)

## Usage

Open `index.html` directly in a browser, or serve the folder with any static file server:

```bash
# Python
python -m http.server 8000

# Node (npx)
npx serve .
```

> **Note:** Opening `index.html` directly via `file://` works for most features. A local server is only needed if your browser restricts `fetch()` on `file://` origins.

## GitHub Pages

To deploy on GitHub Pages:
1. Push this folder to a GitHub repository
2. Go to **Settings → Pages → Source** and select your branch/root
3. Your site will be live at `https://<username>.github.io/<repo>/`

## Tech Stack

- Vanilla HTML, CSS, JavaScript — zero dependencies, no build step
- [Open Library API](https://openlibrary.org/developers/api) for book data & covers
- Google Fonts: Playfair Display, Lora, Barlow
