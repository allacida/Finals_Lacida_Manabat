// ── SHARED STATE (declared first to avoid hoisting issues) ─
let readingList = [];
let bookNotes = {};
let activeSubject = null;
let lastBrowseBooks = [];
let activeYearFrom = null;
let activeYearTo   = null;

// ── AUTH SYSTEM ───────────────────────────────────────────
const USERS_KEY = 'folio_users';
const SESSION_KEY = 'folio_session';

function getUsers() { return JSON.parse(localStorage.getItem(USERS_KEY) || '{}'); }
function saveUsers(u) { localStorage.setItem(USERS_KEY, JSON.stringify(u)); }
function getSession() { return JSON.parse(localStorage.getItem(SESSION_KEY) || 'null'); }
function saveSession(s) { localStorage.setItem(SESSION_KEY, JSON.stringify(s)); }

let currentUser = null;

function switchAuthTab(tab) {
  document.getElementById('formLogin').style.display = tab === 'login' ? '' : 'none';
  document.getElementById('formRegister').style.display = tab === 'register' ? '' : 'none';
  document.getElementById('tabLogin').classList.toggle('active', tab === 'login');
  document.getElementById('tabRegister').classList.toggle('active', tab === 'register');
  showAuthError('');
}

function showAuthError(msg) {
  const el = document.getElementById('authError');
  el.textContent = msg;
  el.classList.toggle('show', !!msg);
}

function doLogin() {
  const username = document.getElementById('loginUser').value.trim();
  const password = document.getElementById('loginPass').value;
  if (!username || !password) return showAuthError('Please fill in all fields.');
  const users = getUsers();
  if (!users[username]) return showAuthError('No account found with that username.');
  if (users[username].password !== btoa(password)) return showAuthError('Incorrect password.');
  loginSuccess(username, users[username].name);
}

function doRegister() {
  const name = document.getElementById('regName').value.trim();
  const username = document.getElementById('regUser').value.trim().toLowerCase();
  const password = document.getElementById('regPass').value;
  if (!name || !username || !password) return showAuthError('Please fill in all fields.');
  if (username.length < 3) return showAuthError('Username must be at least 3 characters.');
  if (password.length < 6) return showAuthError('Password must be at least 6 characters.');
  if (!/^[a-z0-9_]+$/.test(username)) return showAuthError('Username: letters, numbers, underscores only.');
  const users = getUsers();
  if (users[username]) return showAuthError('That username is already taken.');
  users[username] = { name, password: btoa(password), createdAt: new Date().toISOString() };
  saveUsers(users);
  loginSuccess(username, name);
}

function loginSuccess(username, name) {
  currentUser = { username, name };
  saveSession(currentUser);
  // Switch to user-scoped storage keys
  syncUserData();
  // Update UI
  document.getElementById('userAvatar').textContent = name.charAt(0).toUpperCase();
  document.getElementById('userNameDisplay').textContent = name;
  document.getElementById('userBadge').style.display = 'flex';
  // Hide auth screen
  const screen = document.getElementById('authScreen');
  screen.classList.add('hidden');
  setTimeout(() => screen.style.display = 'none', 400);
  // Init app
  appInit();
}

function doLogout() {
  if (!confirm('Log out of FOLIO?')) return;
  saveSession(null);
  currentUser = null;
  // Reset state
  readingList = [];
  bookNotes = {};
  // Show auth screen again
  const screen = document.getElementById('authScreen');
  screen.style.display = 'flex';
  setTimeout(() => screen.classList.remove('hidden'), 10);
  // Clear inputs
  ['loginUser','loginPass','regName','regUser','regPass'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  showAuthError('');
  switchAuthTab('login');
  document.getElementById('userBadge').style.display = 'none';
}

function userKey(suffix) {
  return `folio_${currentUser.username}_${suffix}`;
}

function syncUserData() {
  const rlKey    = currentUser ? `folio_${currentUser.username}_rl`    : 'folio_guest_rl';
  const notesKey = currentUser ? `folio_${currentUser.username}_notes` : 'folio_guest_notes';
  readingList = JSON.parse(localStorage.getItem(rlKey)    || '[]');
  bookNotes   = JSON.parse(localStorage.getItem(notesKey) || '{}');
}

// Override storage functions to be user-scoped
function saveRL() {
  const key = currentUser ? `folio_${currentUser.username}_rl` : 'folio_guest_rl';
  localStorage.setItem(key, JSON.stringify(readingList));
}
function saveNotes() {
  const key = currentUser ? `folio_${currentUser.username}_notes` : 'folio_guest_notes';
  localStorage.setItem(key, JSON.stringify(bookNotes));
}

// Enter key support for auth inputs
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('loginPass').addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });
  document.getElementById('loginUser').addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });
  document.getElementById('regPass').addEventListener('keydown', e => { if (e.key === 'Enter') doRegister(); });
});

// Auto-login if session exists
(function checkSession() {
  const session = getSession();
  if (session) {
    currentUser = session;
    syncUserData();
    const screen = document.getElementById('authScreen');
    screen.style.display = 'none';
    document.getElementById('userAvatar').textContent = session.name.charAt(0).toUpperCase();
    document.getElementById('userNameDisplay').textContent = session.name;
    document.getElementById('userBadge').style.display = 'flex';
  }
})();

// ── CONFIG ────────────────────────────────────────────────
// Open Library API — completely free, no API key required!
// Docs: https://openlibrary.org/developers/api
const OL   = 'https://openlibrary.org';
const OLIMG = 'https://covers.openlibrary.org/b';

// ── STATE ────────────────────────────────────────────────
// (declared at top of script)

// ── UTILS ────────────────────────────────────────────────
const $ = id => document.getElementById(id);

function coverUrl(coverId, size = 'M') {
  return coverId ? `${OLIMG}/id/${coverId}-${size}.jpg` : null;
}

function isbnCoverUrl(isbn, size = 'M') {
  return `${OLIMG}/isbn/${isbn}-${size}.jpg`;
}

async function apiFetch(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

// ── READING LIST ─────────────────────────────────────────
function isInRL(key) { return readingList.some(b => b.key === key); }

function toggleRL(book) {
  const wasIn = isInRL(book.key);
  if (wasIn) {
    readingList = readingList.filter(b => b.key !== book.key);
  } else {
    readingList.push(book);
  }
  saveRL();
  updateRLUI();
  if (typeof showToast === 'function') {
    wasIn
      ? showToast(`"${book.title}" removed from reading list.`)
      : showToast(`"${book.title}" added to reading list! 📚`, 'success');
  }
}

function updateRLUI() {
  const cnt = readingList.length;
  const rlCount = $('rlCount');
  if (rlCount) rlCount.textContent = cnt ? `(${cnt})` : '';
  const rlPageCount = $('rlPageCount');
  if (rlPageCount) rlPageCount.textContent = cnt ? `${cnt} books` : '';

  const sidebar = $('sidebarRL');
  if (!cnt) {
    sidebar.innerHTML = '<div class="empty-rl">Your list is empty.<br>Add books to track them here.</div>';
    return;
  }
  sidebar.innerHTML = readingList.map(b => {
    const cover = b.coverId ? coverUrl(b.coverId, 'S') : null;
    return `<div class="reading-list-item" onclick="openModal('${b.key}')">
      ${cover
        ? `<img class="rl-cover" src="${cover}" alt="" loading="lazy" />`
        : `<div class="rl-cover" style="background:var(--parchment2);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:1.2rem;">📖</div>`}
      <div class="rl-info">
        <div class="rl-title">${b.title}</div>
        <div class="rl-author">${b.author || '—'}</div>
      </div>
      <button class="rl-remove" onclick="event.stopPropagation();removeRL('${b.key}')">×</button>
    </div>`;
  }).join('');
}

function removeRL(key) {
  readingList = readingList.filter(b => b.key !== key);
  saveRL();
  updateRLUI();
  if ($('page-reading-list').classList.contains('active')) renderRLPage();
}

function renderRLPage() {
  const grid = $('rlGrid');
  if (!readingList.length) {
    grid.innerHTML = `<div class="state-box">
      <svg width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" style="opacity:0.3">
        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
      </svg>
      <p>No books in your reading list yet.<br>Browse or search to add some.</p>
      <button class="btn-primary" onclick="showPage('browse')">Browse Books</button>
    </div>`;
    return;
  }
  renderGrid(grid, readingList);
}

// ── BOOK CARDS ───────────────────────────────────────────
function bookCard(book, delay = 0) {
  const cover = book.coverId ? coverUrl(book.coverId) : null;
  const inRL = isInRL(book.key);
  const div = document.createElement('div');
  div.className = 'book-card';
  div.style.animationDelay = `${delay}s`;
  const authorStr = Array.isArray(book.author_name)
    ? book.author_name[0] : (book.author || '');
  const yr = book.first_publish_year || book.year || '';

  div.innerHTML = `
    <div class="book-spine">
      ${cover
        ? `<img src="${cover}" alt="${book.title}" loading="lazy" onerror="this.parentNode.innerHTML=noCoverHTML('${escHtml(book.title)}','${escHtml(authorStr)}')" />`
        : noCoverHTML(book.title, authorStr)}
      ${inRL ? '<div class="book-read-badge">✓</div>' : ''}
    </div>
    <div class="book-info">
      <div class="book-title">${book.title}</div>
      ${authorStr ? `<div class="book-author">${authorStr}</div>` : ''}
      ${yr ? `<div class="book-year">${yr}</div>` : ''}
    </div>`;

  div.addEventListener('click', () => openModal(book.key, book));
  return div;
}

function noCoverHTML(title, author) {
  const colors = ['#8b3a2a','#4a6741','#2a4a6a','#6a4a2a','#4a2a6a'];
  const bg = colors[Math.abs(hashStr(title)) % colors.length];
  return `<div class="book-noCover" style="background:${bg}20">
    <div class="book-noCover-title" style="color:${bg}">${escHtml(title)}</div>
    <div class="book-noCover-author">${escHtml(author)}</div>
  </div>`;
}

function escHtml(str) {
  return (str||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function hashStr(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
  return h;
}

function renderGrid(container, books) {
  container.innerHTML = '';
  if (!books.length) {
    container.innerHTML = '<div class="state-box"><p>No books found. Try a different search.</p></div>';
    return;
  }
  const grid = document.createElement('div');
  grid.className = 'book-grid';
  books.forEach((b, i) => grid.appendChild(bookCard(b, i * 0.03)));
  container.appendChild(grid);
}

// ── YEAR FILTER ──────────────────────────────────────────
// (activeYearFrom, activeYearTo, lastBrowseBooks declared at top)

function applyYearFilter() {
  const from = parseInt($('yearFrom').value) || null;
  const to   = parseInt($('yearTo').value)   || null;
  activeYearFrom = from;
  activeYearTo   = to;

  const hasFilter = from || to;
  $('yearClearBtn').style.display = hasFilter ? '' : 'none';

  const filtered = filterByYear(lastBrowseBooks);
  const badge = hasFilter ? `<span class="filter-badge">${from || '...'}&#8211;${to || '...'}</span>` : '';
  $('browseCount').innerHTML = `${filtered.length} books${badge}`;
  renderGrid($('browseGrid'), filtered);
}

function clearYearFilter() {
  activeYearFrom = null;
  activeYearTo   = null;
  $('yearFrom').value = '';
  $('yearTo').value   = '';
  $('yearClearBtn').style.display = 'none';
  $('browseCount').textContent = lastBrowseBooks.length + ' books';
  renderGrid($('browseGrid'), lastBrowseBooks);
}

function filterByYear(books) {
  return books.filter(b => {
    const yr = b.year || b.first_publish_year;
    if (!yr) return true;
    if (activeYearFrom && yr < activeYearFrom) return false;
    if (activeYearTo   && yr > activeYearTo)   return false;
    return true;
  });
}

// ── SUBJECTS ─────────────────────────────────────────────
const SUBJECTS = [
  'Science Fiction','Fantasy','Mystery','History','Philosophy',
  'Biography','Psychology','Classic Literature','Art','Science',
  'Adventure','Romance','Technology','Poetry','Politics'
];

function renderSubjects() {
  const wrap = $('subjectChips');
  SUBJECTS.forEach(s => {
    const btn = document.createElement('button');
    btn.className = 'subject-chip';
    btn.textContent = s;
    btn.onclick = () => loadSubject(s, btn);
    wrap.appendChild(btn);
  });
}

async function loadSubject(subject, btn) {
  // toggle active chip
  document.querySelectorAll('.subject-chip').forEach(c => c.classList.remove('active'));
  if (btn) btn.classList.add('active');

  showPage('browse');
  $('browseTitle').textContent = subject;
  $('browseCount').textContent = 'Loading…';
  $('browseGrid').innerHTML = '<div class="state-box"><div class="spinner"></div></div>';

  try {
    const slug = subject.toLowerCase().replace(/ /g,'_');
    const data = await apiFetch(`${OL}/subjects/${slug}.json?limit=24`);
    const books = (data.works || []).map(w => ({
      key: w.key,
      title: w.title,
      author: w.authors?.[0]?.name || '',
      coverId: w.cover_id,
      year: w.first_publish_year,
    }));
    lastBrowseBooks = books;
    const filtered = filterByYear(books);
    $('browseCount').textContent = `${data.work_count?.toLocaleString() || books.length} books`;
    renderGrid($('browseGrid'), filtered);
  } catch(err) {
    $('browseGrid').innerHTML = `<div class="state-box"><p>Failed to load subject.<br><small>${err.message}</small></p></div>`;
  }
}

// ── TRENDING / DEFAULT BROWSE ─────────────────────────────
async function loadTrending() {
  $('browseTitle').textContent = 'Trending This Week';
  $('browseCount').textContent = 'Loading…';
  $('browseGrid').innerHTML = '<div class="state-box"><div class="spinner"></div></div>';
  try {
    // Use a well-known beloved subject as "trending" fallback
    const data = await apiFetch(`${OL}/search.json?q=subject:fiction&sort=rating&limit=24&fields=key,title,author_name,first_publish_year,cover_i`);
    const books = (data.docs || []).map(d => ({
      key: d.key,
      title: d.title,
      author_name: d.author_name,
      author: (d.author_name||[])[0] || '',
      coverId: d.cover_i,
      first_publish_year: d.first_publish_year,
    }));
    lastBrowseBooks = books;
    const filtered = filterByYear(books);
    $('browseCount').textContent = `${data.numFound?.toLocaleString() || ''} results`;
    renderGrid($('browseGrid'), filtered);
  } catch(err) {
    $('browseGrid').innerHTML = `<div class="state-box"><p>Could not load books.<br><small>${err.message}</small></p></div>`;
  }
}

// ── SEARCH ────────────────────────────────────────────────
async function doSearch() {
  const query = $('searchInput').value.trim();
  const type  = $('searchType').value;
  if (!query) return;

  showPage('search');
  $('searchHeading').textContent = `"${query}"`;
  $('searchCount').textContent = 'Searching…';
  $('searchGrid').innerHTML = '<div class="state-box"><div class="spinner"></div></div>';

  try {
    const params = new URLSearchParams({ limit: 32, fields: 'key,title,author_name,first_publish_year,cover_i' });
    params.set(type, query);
    const data = await apiFetch(`${OL}/search.json?${params}`);
    const books = (data.docs || []).map(d => ({
      key: d.key,
      title: d.title,
      author_name: d.author_name,
      author: (d.author_name||[])[0] || '',
      coverId: d.cover_i,
      first_publish_year: d.first_publish_year,
    }));
    $('searchCount').textContent = `${data.numFound?.toLocaleString() || 0} results`;
    renderGrid($('searchGrid'), books);
  } catch(err) {
    $('searchGrid').innerHTML = `<div class="state-box"><p>Search failed.<br><small>${err.message}</small></p></div>`;
    $('searchCount').textContent = 'Error';
  }
}

$('searchInput').addEventListener('keydown', e => { if (e.key === 'Enter') doSearch(); });

// Year filter Enter key
['yearFrom','yearTo'].forEach(id => {
  const el = $(id);
  if (el) el.addEventListener('keydown', e => { if (e.key === 'Enter') applyYearFilter(); });
});

// ── ISBN LOOKUP ───────────────────────────────────────────
async function isbnLookup() {
  const isbn = $('isbnInput').value.trim().replace(/[-\s]/g,'');
  if (!isbn) return;
  try {
    const data = await apiFetch(`${OL}/isbn/${isbn}.json`);
    const key = data.works?.[0]?.key || `/books/${data.key}`;
    openModal(key, { title: data.title, coverId: data.covers?.[0] });
  } catch(err) {
    alert(`ISBN not found: ${err.message}`);
  }
}

$('isbnInput').addEventListener('keydown', e => { if (e.key === 'Enter') isbnLookup(); });

// ── MODAL ─────────────────────────────────────────────────
async function openModal(key, basicInfo = {}) {
  const overlay = $('overlay');
  const content = $('modalContent');
  overlay.classList.add('open');
  document.body.style.overflow = 'hidden';
  content.innerHTML = '<div class="state-box"><div class="spinner"></div><p>Fetching details…</p></div>';

  try {
    const workKey = key.startsWith('/works/') ? key : key;
    const data = await apiFetch(`${OL}${workKey}.json`);

    // Get author details
    let authorName = basicInfo.author || '';
    if (!authorName && data.authors?.length) {
      try {
        const aData = await apiFetch(`${OL}${data.authors[0].author.key}.json`);
        authorName = aData.name || '';
      } catch {}
    }

    // Description
    let desc = '';
    if (data.description) {
      desc = typeof data.description === 'string' ? data.description : data.description.value || '';
    }

    // Cover
    const coverId = data.covers?.[0] || basicInfo.coverId;
    const coverSrc = coverId ? coverUrl(coverId, 'L') : null;

    // Subjects (top 8)
    const subjects = (data.subjects || []).slice(0, 8);

    // OL URL
    const olUrl = `https://openlibrary.org${workKey}`;

    // Build RL object
    const rlBook = {
      key: workKey,
      title: data.title || basicInfo.title || 'Unknown',
      author: authorName,
      coverId,
    };

    const inRL = isInRL(workKey);

    // Store modal context safely in JS (avoids HTML attribute escaping bugs)
    window._modalBook = rlBook;
    window._modalWorkKey = workKey;

    content.innerHTML = `
      <div class="modal-inner">
        <div class="modal-cover">
          ${coverSrc
            ? `<img src="${coverSrc}" alt="${escHtml(data.title)}" />`
            : `<div class="modal-cover-placeholder">
                <svg width="40" height="40" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" style="opacity:0.3"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
              </div>`}
        </div>
        <div class="modal-details">
          <div class="modal-title">${escHtml(data.title || basicInfo.title || '—')}</div>
          ${data.subtitle ? `<div class="modal-subtitle">${escHtml(data.subtitle)}</div>` : ''}
          <div class="modal-meta">
            ${authorName ? `<span class="meta-pill"><strong>Author</strong> ${escHtml(authorName)}</span>` : ''}
            ${data.first_publish_date ? `<span class="meta-pill"><strong>Published</strong> ${escHtml(data.first_publish_date)}</span>` : ''}
            ${basicInfo.first_publish_year ? `<span class="meta-pill"><strong>Year</strong> ${basicInfo.first_publish_year}</span>` : ''}
          </div>
          ${desc ? `<div class="modal-desc">${escHtml(desc.slice(0, 800))}${desc.length > 800 ? '…' : ''}</div>` : '<div class="modal-desc" style="opacity:0.5;font-style:italic">No description available.</div>'}
          ${subjects.length ? `
            <div class="modal-subjects">
              ${subjects.map(s => `<span class="subj-tag">${escHtml(s)}</span>`).join('')}
            </div>` : ''}
          <div class="modal-actions">
            <button class="btn-primary" id="rlModalBtn" onclick="toggleRLModal()">
              ${inRL ? '✓ In Reading List' : '+ Add to Reading List'}
            </button>
            <a href="${olUrl}" target="_blank" class="btn-outline">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
              Open Library Page
            </a>
          </div>
          <div class="notes-section">
            <div class="notes-section-head">📝 My Notes &amp; Highlights</div>
            <textarea class="notes-textarea" id="bookNotesArea"
              placeholder="Jot down your thoughts, favourite passages, quotes, or highlights while reading…">${escHtml(getNoteForKey(workKey))}</textarea>
            <div class="notes-actions">
              <button class="notes-save" onclick="saveNote()">Save Note</button>
              <span class="notes-saved-msg" id="notesSavedMsg">✓ Saved!</span>
            </div>
          </div>
        </div>
      </div>`;
  } catch(err) {
    content.innerHTML = `<div class="state-box"><p>Failed to load book details.<br><small>${err.message}</small></p></div>`;
  }
}

function toggleRLModal() {
  const book = window._modalBook;
  if (!book) return;
  toggleRL(book);
  const btn = $('rlModalBtn');
  if (btn) btn.textContent = isInRL(book.key) ? '✓ In Reading List' : '+ Add to Reading List';
  if (btn) btn.classList.toggle('in-rl', isInRL(book.key));
}

function closeModal() {
  $('overlay').classList.remove('open');
  document.body.style.overflow = '';
  $('modalContent').innerHTML = '';
  window._modalBook = null;
  window._modalWorkKey = null;
}

function handleOverlayClick(e) {
  if (e.target === $('overlay')) closeModal();
}

document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

// ── NAVIGATION ────────────────────────────────────────────
function showPage(pageId, btn) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const pg = $(`page-${pageId}`);
  if (pg) pg.classList.add('active');

  if (pageId === 'reading-list') renderRLPage();
  if (pageId === 'notes') renderNotesPage();

  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  if (btn) {
    btn.classList.add('active');
  }
}

// ── BOOK NOTES ────────────────────────────────────────────
// bookNotes declared at top of script
// bookNotes[workKey] = { text, bookInfo, savedAt }

function getNoteForKey(key) {
  return bookNotes[key]?.text || '';
}

function saveNote() {
  const workKey = window._modalWorkKey;
  const book = window._modalBook;
  const textarea = $('bookNotesArea');
  if (!textarea || !workKey || !book) return;
  const text = textarea.value.trim();
  if (text) {
    bookNotes[workKey] = {
      text,
      title: book.title || '',
      author: book.author || '',
      coverId: book.coverId || null,
      savedAt: new Date().toISOString(),
    };
  } else {
    delete bookNotes[workKey];
  }
  saveNotes();
  updateNotesCount();
  const msg = $('notesSavedMsg');
  if (msg) {
    msg.classList.add('show');
    setTimeout(() => msg.classList.remove('show'), 2000);
  }
}

function updateNotesCount() {
  const cnt = Object.keys(bookNotes).length;
  const el = $('notesCount');
  if (el) el.textContent = cnt ? `(${cnt})` : '';
  const pg = $('notesPageCount');
  if (pg) pg.textContent = cnt ? `${cnt} notes` : '';
}

function renderNotesPage() {
  const grid = $('notesGrid');
  const entries = Object.entries(bookNotes);
  if (!entries.length) {
    grid.innerHTML = `<div class="state-box">
      <svg width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" style="opacity:0.3">
        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
      </svg>
      <p>No notes yet.<br>Open any book and jot down your thoughts or highlights.</p>
      <button class="btn-primary" onclick="showPage('browse')">Browse Books</button>
    </div>`;
    return;
  }

  // Sort by most recently saved
  entries.sort((a, b) => new Date(b[1].savedAt) - new Date(a[1].savedAt));

  grid.innerHTML = entries.map(([key, note]) => {
    const cover = note.coverId ? coverUrl(note.coverId, 'S') : null;
    const date = note.savedAt ? new Date(note.savedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '';
    const preview = note.text.length > 300 ? note.text.slice(0, 300) + '…' : note.text;
    return `<div class="notes-list-item" onclick="openModal('${key}')">
      <div class="nli-header">
        ${cover
          ? `<img class="nli-cover" src="${cover}" alt="" loading="lazy" />`
          : `<div class="nli-cover" style="display:flex;align-items:center;justify-content:center;font-size:1.2rem;">📖</div>`}
        <div>
          <div class="nli-title">${escHtml(note.title || key)}</div>
          ${note.author ? `<div class="nli-author">${escHtml(note.author)}</div>` : ''}
        </div>
      </div>
      <div class="nli-note-text">${escHtml(preview)}</div>
      ${date ? `<div class="nli-date">Last saved ${date}</div>` : ''}
    </div>`;
  }).join('');
}

// ── DARK MODE ─────────────────────────────────────────────
function toggleDark() {
  const isDark = document.documentElement.classList.toggle('dark');
  document.body.classList.toggle('dark', isDark);
  const btn = $('darkToggleBtn');
  if (btn) btn.textContent = isDark ? '☽ Dark' : '☀ Light';
  localStorage.setItem('folio_dark', isDark ? '1' : '');
}

// Restore dark preference on load
(function() {
  if (localStorage.getItem('folio_dark') === '1') {
    document.documentElement.classList.add('dark');
    document.body.classList.add('dark');
    const btn = document.getElementById('darkToggleBtn');
    if (btn) btn.textContent = '☽ Dark';
  }
})();

// ── INIT ──────────────────────────────────────────────────
function appInit() {
  renderSubjects();
  updateRLUI();
  updateNotesCount();
  loadTrending();
}

// ── TOAST NOTIFICATIONS ──────────────────────────────────
function showToast(message, type = '') {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = `toast${type ? ' toast-' + type : ''}`;
  toast.textContent = message;
  container.appendChild(toast);
  requestAnimationFrame(() => {
    requestAnimationFrame(() => toast.classList.add('show'));
  });
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, 2800);
}

// Patch updateRLUI to also refresh the RL page grid and show toast
const _origUpdateRLUI = updateRLUI;
updateRLUI = function() {
  _origUpdateRLUI();
  if ($('page-reading-list') && $('page-reading-list').classList.contains('active')) {
    renderRLPage();
  }
};

// ── SCROLL TO TOP ─────────────────────────────────────────
window.addEventListener('scroll', () => {
  const btn = document.getElementById('scrollTopBtn');
  if (btn) btn.classList.toggle('visible', window.scrollY > 320);
});

function scrollToTop() {
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ── RANDOM BOOK PICKER ────────────────────────────────────
function pickRandomBook() {
  const books = lastBrowseBooks.length ? lastBrowseBooks : readingList;
  if (!books.length) {
    showToast('No books loaded yet. Browse a subject first!', 'info');
    return;
  }
  const pick = books[Math.floor(Math.random() * books.length)];
  showToast(`🎲 Random pick: "${pick.title}"`, 'info');
  openModal(pick.key, pick);
}

// ── EXPORT READING LIST ───────────────────────────────────
function exportReadingList() {
  if (!readingList.length) {
    showToast('Your reading list is empty!', 'info');
    return;
  }
  const lines = [
    'FOLIO — My Reading List',
    `Exported: ${new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}`,
    `Total: ${readingList.length} book${readingList.length !== 1 ? 's' : ''}`,
    '',
    ...readingList.map((b, i) => {
      const author = b.author ? ` — ${b.author}` : '';
      const year = b.first_publish_year || b.year ? ` (${b.first_publish_year || b.year})` : '';
      return `${i + 1}. ${b.title}${author}${year}`;
    }),
    '',
    `https://openlibrary.org`,
  ];
  const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'folio-reading-list.txt';
  a.click();
  URL.revokeObjectURL(url);
  showToast(`Exported ${readingList.length} books ✓`, 'success');
}

// ── KEYBOARD SHORTCUTS ────────────────────────────────────
document.addEventListener('keydown', e => {
  const tag = document.activeElement.tagName;
  const typing = tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT';

  // Esc already handled for book modal above; also close kb overlay
  if (e.key === 'Escape') {
    document.getElementById('kbOverlay').classList.remove('open');
    return; // let existing Escape handler close book modal too
  }

  if (typing) return; // don't hijack shortcuts while user is typing

  switch(e.key) {
    case '/':
    case 's':
    case 'S':
      e.preventDefault();
      const si = document.getElementById('searchInput');
      if (si) { si.focus(); si.select(); }
      break;
    case 'b':
    case 'B':
      showPage('browse', document.querySelector('.nav-btn'));
      break;
    case 'r':
    case 'R':
      showPage('reading-list', document.querySelectorAll('.nav-btn')[1]);
      break;
    case 'n':
    case 'N':
      showPage('notes', document.querySelectorAll('.nav-btn')[2]);
      break;
    case 'd':
    case 'D':
      toggleDark();
      break;
    case 'x':
    case 'X':
      pickRandomBook();
      break;
    case '?':
      document.getElementById('kbOverlay').classList.add('open');
      break;
  }
});

function closeKbModal(e) {
  if (e.target === document.getElementById('kbOverlay')) {
    document.getElementById('kbOverlay').classList.remove('open');
  }
}

// Only auto-init if already logged in (session restored above)
if (currentUser) appInit();
